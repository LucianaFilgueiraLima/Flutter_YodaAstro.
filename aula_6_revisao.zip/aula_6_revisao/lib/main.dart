import 'package:flutter/material.dart';
// // // // // void parte da estrutura do app
// // // // void main () {
// // // //     runApp (MaterialApp(
// // //
// // // //         home: Text (
// // // //           "Hello World!"
// // // //       ),
// // // //   ));
// // // //  }
// // //
// // // // class column
// // // void main() {
// // //   runApp(MaterialApp(// coluna trabalha na vertical
// // //     home: Column(// children - filhos = classe filhos, múltiplas
// // //       //child = filho 1 para 1, apenas com uma classe
// // //         children: <Widget> [
// // //           Text('Entregue recursos mais Rapidamente'),
// // //           Text('Crie belas UI e UX com Flutter sdk'),
// // //     //expandindo fittebox acomoda a logo
// // //     Expanded(
// // //       child: FittedBox(
// // //         child: FlutterLogo(),
// // //       ),
// // //
// // //     ),
// // //   ));
// //
// // // }
// //
// // void main () {
// //   //column
// //   runApp(MaterialApp(
// //     debugShowCheckedModeBanner: false,
// //     home: Column(
// //       //coliuna  vai a esquerda do display do app
// //       crossAxisAlignment: CrossAxisAlignment.start,
// //       //tamanho da  coluna
// //       mainAxisSize: MainAxisSize.min,
// //       // coluna fica centralizada
// //       mainAxisAlignment: MainAxisAlignment.center,
// //       children: <Widget>[
// //         const Text ('O senso comum é menos comum de todos de todos os sensos'),
// //         const Text ('Aquelse que riem por último riem sempre pensam mais devagar'),
// //         Text ('o palmeiras  não tem mundial', style: TextStyle(
// //           fontSize: 20.0,
// //           fontStyle: FontStyle.italic,
// //           color: Colors.white,
// //       ],
// //     ),
// //   ));
// // }
// void main () {
//   // Column
//   runApp(MaterialApp(
//     debugShowCheckedModeBanner: false,
//     home: Column(
//       //coluna vai na esqueda do display do app
//       crossAxisAlignment: CrossAxisAlignment.start,
//       //tamanho da coluna
//       mainAxisSize: MainAxisSize.min,
//       //coluna vai ficar no centro do display do app
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: <Widget>[
//         const Text('O senso comum é o menos comum de todos os sensos'),
//         const Text('Aqueles que riem por último sempre pensam mais devagar'),
//         Text('O palmeiras não tem mundial',style: TextStyle(
//           fontSize: 20.0,
//           fontStyle: FontStyle.italic,
//           color: Colors.white,
//         ),),
//       ],
//     ),
//   ));
// }
// void main () {
//   runApp(MaterialApp(
//     home:Center(
//       child: Container(
//         margin: const EdgeInsets.all (10.0),
//         color: Colors.lightBlue,
//         width: 48.0,
//         height: 48.8,
//       ),
//     ),
//   ));
// }
// void main () {
//   runApp(MaterialApp(
//     //Container
//     home: Center (
//       child: Container(
//         padding: const EdgeInsets.all(8.0),
//         color: Colors.green,
//         alignment: Alignment.center,
//         //faz a rotação
//         transform: Matrix4.rotationZ(0.1),
//         child: Text(
//           'Hello World',
//           style: TextStyle(
//             color: Colors.white
//
//           ),
//
//
//       ),
//       ),
//
//   ),
//
//   ));
// }

// void main() {
//   runApp(MaterialApp(
//     debugShowCheckedModeBanner: false,
//     home: FlutterLogo(
//       size: 100,
//       //logo na hoorizontal do Display do App
//       style: FlutterLogoStyle.horizontal,
//       // Curvatura
//       curve: Curves.bounceInOut,
//       //tempo em segundos
//       duration: Duration(seconds: 5),
//     ),
//
//   ));
// }

void main () {
  runApp(MaterialApp(
    home: Row(

      //Centralizado no Display
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: <Widget> [
        Icon(
          Icons.favorite,
          color: Colors.pink,
          size:25,
          semanticLabel: 'Text',
          ),
          Icon(
            Icons.audiotrack,
            color: Colors.green,
            size: 30.0,
          ),
          Icon(
            Icons.beach_access,
            color: Colors.blue,
              size: 36,
          ),

      ]
    ),
  ));
}