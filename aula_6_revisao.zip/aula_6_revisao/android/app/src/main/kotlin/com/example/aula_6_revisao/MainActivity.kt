package com.example.aula_6_revisao

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
